(function() {
    FastClick.attach(document.body);
	    //do your thing.
})();